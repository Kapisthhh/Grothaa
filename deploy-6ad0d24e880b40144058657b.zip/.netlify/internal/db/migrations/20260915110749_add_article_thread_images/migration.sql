ALTER TABLE "articles" ADD COLUMN "image_key" text;--> statement-breakpoint
ALTER TABLE "articles" ADD COLUMN "image_alt" text;--> statement-breakpoint
ALTER TABLE "threads" ADD COLUMN "image_key" text;--> statement-breakpoint
ALTER TABLE "threads" ADD COLUMN "image_alt" text;