CREATE TABLE "thread_replies" (
	"id" serial PRIMARY KEY,
	"thread_id" integer NOT NULL,
	"body" text NOT NULL,
	"author" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "thread_replies" ADD CONSTRAINT "thread_replies_thread_id_threads_id_fkey" FOREIGN KEY ("thread_id") REFERENCES "threads"("id") ON DELETE CASCADE;